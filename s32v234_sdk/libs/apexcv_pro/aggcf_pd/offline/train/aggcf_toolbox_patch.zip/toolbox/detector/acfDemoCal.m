% Demo for aggregate channel features object detector on Caltech dataset.
%
% See also acfReadme.m
%
% Piotr's Computer Vision Matlab Toolbox      Version 3.40
% Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
% Licensed under the Simplified BSD License [see external/bsd.txt]

%% extract training and testing images and ground truth
cd(fileparts(which('acfDemoCal.m'))); 

%% train/test dir
dataDir='../../data/Caltech/';
testDataDir=[dataDir 'test/'];
trainDataDir=[dataDir 'train/'];

%% set up opts for training detector (see acfTrain)
opts=acfTrain(); opts.modelDs=[64 32]; opts.modelDsPad=[64 32];
opts.pPyramid.pChns.pColor.smooth=0; 
opts.nWeak=[64 256 1024 2048];
opts.pBoost.pTree.maxDepth=4; 
opts.pBoost.discrete=0;
opts.pBoost.pTree.fracFtrs=1/16; opts.nNeg=25000; opts.nAccNeg=50000;
opts.pPyramid.pChns.pGradHist.softBin=1; opts.pJitter=struct('flip',1);
opts.posGtDir=[trainDataDir '' '/annotations'];
opts.posImgDir=[trainDataDir '' '/images'];

opts.pPyramid.pChns.shrink=2; opts.name='models/aggcf+';
pLoad={'lbls',{'person'},'ilbls',{'people'},'squarify',{3,.41}};
opts.pLoad = [pLoad 'hRng',[50 inf], 'vRng',[1 1] ];

%% train detector (see acfTrain)
detector = acfTrain( opts );

pModify=struct('cascThr',-1,'cascCal',.025);
%% run detector on a sample image (see acfDetect)
%I=imread('D:\matlabWorkspace\data\Caltech\test\images\set07_V000_I01589.jpg'); tic, bbs=acfDetect(I,detector); toc
%figure(1); im(I); bbApply('draw',bbs); pause(.1);

%% test detector and plot roc (see acfTest)
[~,~,gt,dt]=acfTest('name',opts.name,'imgDir',[testDataDir '/images'],...
  'gtDir',[testDataDir '/annotations'],'pLoad',[pLoad, 'hRng',[50 inf],...
  'vRng',[.65 1],'xRng',[5 635],'yRng',[5 475]],...
  'pModify',pModify,'reapply',0,'show',2);
