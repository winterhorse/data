% Piotr's Computer Vision Matlab Toolbox      Version 3.50
% Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
% Licensed under the Simplified BSD License [see external/bsd.txt]
%Copyright 2018 NXP

%wrapper function for private convertDetector
function convertDetector(f, d)
convertDetector(f, d);
end