% Compile all C/C++ libraries related to AggCF detector
%
% Piotr's Computer Vision Matlab Toolbox      Version 3.30
% Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
% Licensed under the Simplified BSD License [see external/bsd.txt]
% Copyright 2018 NXP

% compile options including openmp support for C++ files
opts = {'-output'};
isoctave=0;

if(exist('OCTAVE_VERSION','builtin')), isoctave = 1; end

optsOmp={};

if(isoctave),
  opts={'--mex', '-DMATLAB_MEX_FILE', '-o'};
  optsOmp=[] %no openmp support for octave as of yet
else
  if(version('-release') >= '2017a'),
    opts=['-compatibleArrayDims' opts];
  end
  cc=mex.getCompilerConfigurations('cpp');
  if(strfind(cc.Name, 'Microsoft Visual C++'))
    optsOmp={'OPTIMFLAGS="$OPTIMFLAGS','/openmp"'};
	optsOmp=[optsOmp '-DUSEOMP'];
  elseif (strfind(cc.Name, 'MinGW64 Compiler (C++)')),
    optsOmp={'CXXFLAGS="$CXXFLAGS','-fopenmp"'};
    optsOmp=[optsOmp,'LDFLAGS="$LDFLAGS','-fopenmp"']
    optsOmp=[optsOmp '-DUSEOMP'];
  end
end

% list of files (missing /private/ part of directory)
fs={ 'channels/convConst.cpp',...
 'channels/imPadMex.cpp',...
 'channels/gradientMex.cpp',...
 'channels/imResampleMex.cpp',...
 'channels/rgbConvertMex.cpp',...
 'channels/imResizeMex.cpp',...
 'classify/binaryTreeTrain1.cpp',...
 'classify/fernsInds1.c',...
 'classify/forestFindThr.cpp',...
 'classify/forestInds.cpp',...
 'classify/meanShift1.c',...
 'detector/acfDetect1.cpp',...
 'detector/convertDetector.cpp',...
 'images/assignToBins1.c',...
 'images/histc2c.c',...
 'images/imtransform2_c.c',...
 'images/nlfiltersep_max.c',...
 'images/nlfiltersep_sum.c',...
 'videos/ktComputeW_c.c',...
 'videos/ktHistcRgb_c.c',...
 'videos/opticalFlowHsMex.cpp'};
 
n=length(fs); useOmp=zeros(1,n); 
if(~ismac), 
  useOmp([7 10])=1; %binaryTreeTrain1.cpp and forestInds.cpp use openmp
end

% compile every funciton in turn 
disp('Compiling Piotr''s AggCF Toolbox.......................');
rd=fileparts(mfilename('fullpath')); rd=rd(1:end-9); tic;
errmsg=' -> COMPILE FAILURE: ''%s'' %s\n';
for i=1:n
  try %#ok<ALIGN>
    [d,f1,e]=fileparts(fs{i}); f=[rd '\' d '\private\' f1];
    if(useOmp(i)), optsi=[optsOmp opts]; else optsi=opts; end
    fprintf(' -> %s\n',[f e]); mex([f e],optsi{:},[f '.' mexext]);
  catch err, fprintf(errmsg,[f1 e],err.message); end
end

disp('..................................Done Compiling'); toc;
