/*******************************************************************************
* Piotr's Computer Vision Matlab Toolbox      Version 3.00
* Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
* Licensed under the Simplified BSD License [see external/bsd.txt]
* Copyright 2018 NXP
*******************************************************************************/
#include "mex.h"
#include <vector>
#include <cmath>
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

typedef unsigned int uint32;

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )
{
	char *input_buf = mxArrayToString(prhs[0]);
	if (std::ifstream(input_buf))
		if (remove(input_buf) == -1)
     	{
     		cout << "Error deleting file" << endl;
     		return;
     	}
	ofstream detectorFile(input_buf);
	if (!detectorFile)
	{
    	cout << "File could not be created" << endl;
     	return;
	}
	else
	{
		mxArray *trees = mxGetField(prhs[1],0,"clf");
		float *thrs = (float*) mxGetData(mxGetField(trees,0,"thrs"));
	  	float *hs = (float*) mxGetData(mxGetField(trees,0,"hs"));
	  	uint32 *fids = (uint32*) mxGetData(mxGetField(trees,0,"fids"));
	  	uint32 *child = (uint32*) mxGetData(mxGetField(trees,0,"child"));
	  	const int treeDepth = mxGetField(trees,0,"treeDepth")==NULL ? 0 :
	    	(int) mxGetScalar(mxGetField(trees,0,"treeDepth"));
	    const mwSize *fidsSize = mxGetDimensions(mxGetField(trees,0,"fids"));
	  	const int nTreeNodes = (int) fidsSize[0];
	  	const int nTrees = (int) fidsSize[1];
	  	detectorFile << treeDepth << " " << nTreeNodes << " " << nTrees << endl;
	  	for(int i = 0 ; i < 4; ++i)
	  	{
	  		for (int n = 0; n < nTreeNodes; n++)
			    for (int m=0; m < nTrees; m++)
			    	switch(i)
			    	{
			    		case 0:
			    			detectorFile << setprecision(5) << (double)thrs[n*nTrees+m] << " ";
			    			break;
			    		case 1:
			    			detectorFile << setprecision(5) << (double)hs[n*nTrees+m] << " ";
			    			break;
			    		case 2:
			    			detectorFile << fids[n*nTrees+m] << " ";
			    			break;
			    		case 3:
			    			detectorFile << child[n*nTrees+m] << " ";
			    			break;
			    	}
			detectorFile << endl;
	  	}
        
        mxArray *opts = mxGetField(prhs[1],0,"opts");
        double *model = (double*)mxGetData(mxGetField(opts,0,"modelDs"));
        double *modelPad = (double*)mxGetData(mxGetField(opts,0,"modelDsPad"));
        double *stride = (double*)mxGetData(mxGetField(opts,0,"stride"));
        double *cascTh = (double*)mxGetData(mxGetField(opts,0,"cascThr")); 
        double *cascCa = (double*)mxGetData(mxGetField(opts,0,"cascCal"));
        
        mxArray *pPyr = mxGetField(opts, 0, "pPyramid");
        double *nPerO = (double*)mxGetData(mxGetField(pPyr,0,"nPerOct"));
        double *nOup = (double*)mxGetData(mxGetField(pPyr,0,"nOctUp"));
        double *nAppr = (double*)mxGetData(mxGetField(pPyr,0,"nApprox"));
        double *minD = (double*)mxGetData(mxGetField(pPyr,0,"minDs"));
        double *smooh = (double*)mxGetData(mxGetField(pPyr,0,"smooth"));
        double *pad = (double*)mxGetData(mxGetField(pPyr,0,"pad"));
        double *lambdas = (double*)mxGetData(mxGetField(pPyr,0,"lambdas"));
        
        mxArray *nms = mxGetField(opts, 0, "pNms");
        double *overlap = (double*)mxGetData(mxGetField(nms,0,"overlap"));
        mxArray *pChns = mxGetField(pPyr, 0, "pChns");
        double *shrink = (double*)mxGetData(mxGetField(pChns,0,"shrink"));
        mxArray *pGradM = mxGetField(pChns, 0, "pGradMag");
        mxArray *pGradH = mxGetField(pChns, 0, "pGradHist");
        double *normRad = (double*)mxGetData(mxGetField(pGradM,0,"normRad"));
        double *normConst = (double*)mxGetData(mxGetField(pGradM,0,"normConst"));
        double *full = (double*)mxGetData(mxGetField(pGradM,0,"full"));
        double *nOrients = (double*)mxGetData(mxGetField(pGradH,0,"nOrients"));
        double *softBin = (double*)mxGetData(mxGetField(pGradH,0,"softBin"));
       

        detectorFile << model[0] << " " << model[1] << " " << modelPad[0] << " " << modelPad[1]<< " "
                << *stride << " " << *cascTh << " " << *cascCa << " " << *nPerO << " " << *nOup << " " << *nAppr << " "
                << minD[0] << " " << minD[1] << " " << *smooh << " " << pad[0] << " " << pad[1] << " " << lambdas[0]
                << " " << lambdas[1] << " " << lambdas[2] << " " << *shrink << " " << *normRad << " " << *normConst 
                << " " << *full << " " << *nOrients << " " << *softBin << " " << *overlap;
	  	detectorFile.close();
	}
}