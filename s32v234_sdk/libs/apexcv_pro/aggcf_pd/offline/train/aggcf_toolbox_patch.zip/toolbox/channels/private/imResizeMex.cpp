/*******************************************************************************
* Piotr's Computer Vision Matlab Toolbox      Version 3.00
* Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
* Licensed under the Simplified BSD License [see external/bsd.txt]
* Copyright 2018 NXP
*******************************************************************************/
#include "wrappers.hpp"
#include "string.h"
#include <math.h>
#include <typeinfo>
#include "sse.hpp"
#include <stdint.h> 
typedef unsigned char uchar;
#define UINT8_MAX        0xff


// Prototypes
int GetCOL(uint16_t* s, uint16_t* dst, int b, int x, int pad, int sh, int ss);
int PutCOL(uint16_t* d, uint16_t* src, int b, int x, int dh, int ds);
int GetROW(uint16_t* s, uint16_t* dst, int b, int y, int pad, int sw, int ss);
int PutROW(uint16_t* d, const uint16_t* src, int b, int y, int dw, int ds);

int
HRSZ_RSZ_POLY(
    uint16_t* pdst,
    const uint16_t* psrc,
    int dsiz,              //!< Destination Size   (OROI)
    int sbeg,              //!< Source Begin       (IROI)
    int sinc,              //!< Source Increment
    const int16_t* fbnk,   //!< Filter Bank Coefficients
    int rphs,              //!< Filter Bank Number of Phases
    int rsiz,              //!< Filter Bank Size (per phase)
    int rscl,              //!< Filter Results Scaling
    int rrnd);             //!< Filter Results Rounding Bias
int
VRSZ_RSZ_POLY(
    uint16_t* pdst,
    const uint16_t* psrc,
    int dsiz,              //!< Destination Size   (OROI)
    int sbeg,              //!< Source Begin       (IROI)
    int sinc,              //!< Source Increment
    const int16_t* fbnk,   //!< Filter Bank Coefficients
    int rphs,              //!< Filter Bank Number of Phases
    int rsiz,              //!< Filter Bank Size (per phase)
    int rscl,              //!< Filter Results Scaling
    int rrnd);             //!< Filter Results Rounding Bias
const short* RSZ_GET_POLY(int i);

// const and defines
// 10 matches the HRSZ scaler hardware implementation
#define HRSZ_Q_F           (16)
// It's possible VRSZ_Q_F should match VRSZ_FIXED_SHIFT in APU_resize.c
#define VRSZ_Q_F           (16)
#define HRSZ_BORDER_CONSTANT  1
#define HRSZ_BORDER_REPLICATE 2
 
 /*!
   Load a grayscale image (U8) and scale ().
 */
int
vertical_Scale_08U(uint16_t *src, int sw, int sh, int ss,
uint16_t *dst, int dw, int dh, int ds)
{
   int rval = 0;
   // temporary line buffer (4K) (input, processing and output)
   const int wpad =   16; // padding width
   const int wmax = 4096 + 2*wpad;

   uint16_t IBUF[wmax];
   uint16_t OBUF[wmax];

   // intput format
   const int16_t ifmt_scl = 7;
   const int16_t ifmt_off = 0;
   int      rsz_mod = -1;
   int      rsz_phs = -1;
   int      rsz_siz =  0;
   const int16_t* rsz_val =  0;

   if       (sh >= 2*dh)
   {
      rsz_mod = 2;
      rsz_phs = 4; // 1
      rsz_siz = 8;
      rsz_val = RSZ_GET_POLY(rsz_mod);
   }
   else if  (sh  >   dh)
   {
      rsz_mod = 1;
      rsz_phs = 8; // 3
      rsz_siz = 4;
      rsz_val = RSZ_GET_POLY(rsz_mod);
   }
   else if  (sh  <   dh)
   {
      rsz_mod = 0;
      rsz_phs = 8; // 3
      rsz_siz = 4;
      rsz_val = RSZ_GET_POLY(rsz_mod);
   }
   const int32_t rsz_scl   =  8;
   const int32_t rsz_rnd   = (1<<(rsz_scl-1));

   const int rsz_one    = (1 << VRSZ_Q_F);
   const int rsz_sinc   = (sh * rsz_one) / dh;
   const int rsz_sbeg   = (rsz_sinc >> 1);
   const int rsz_send   = rsz_sbeg + ((dh-1)*rsz_sinc);

   // output format
   const int16_t ofmt_scl = 7;
   const int16_t ofmt_off = (1 << (ofmt_scl -1));

   {
      for (int y=0; y<dw; ++y)
      {
         GetCOL(src, &IBUF[wpad], 0, y, wpad, sh, ss); //Performs padding also.

         // resize
         if (rsz_mod >= 0)
         {
           VRSZ_RSZ_POLY(&OBUF[wpad], &IBUF[wpad], dh,
                  rsz_sbeg, rsz_sinc,
                  rsz_val, rsz_phs, rsz_siz,
                  rsz_scl, rsz_rnd);
         }
         // scale: ((2^8)-1) / ((2^15)-1) ~= 1 / (2^7)
         PutCOL(dst, &OBUF[wpad], 0, y, dh, ds);
      }
   }


   return rval;
}
int
horizontal_Scale_08U(uint16_t *src, int sw, int sh, int ss,
uint16_t *dst, int dw, int dh, int ds)
{
   int rval = 0;


   // temporary line buffer (4K) (input, processing and output)
   const int wpad =   16;
   const int wmax = 4096 + 2*wpad;

   uint16_t IBUF[wmax];
   uint16_t OBUF[wmax];
   //uint16_t PBUF[16][wmax];

   // intput format
   const int16_t ifmt_scl = 7;
   const int16_t ifmt_off = 0;

   // filter (11-tap, symmetric filter)
   // const int16_t flt_val[] = {  1, 10, 45, 120,  210, 252,  210, 120, 45, 10,  1};
   // const int16_t flt_val[] = { -1,  2, -8,  32, -119, 444, -119,  32, -8,  2, -1 };
   // const int16_t flt_siz   = 11;
   // const int16_t flt_scl   =  8;
   // const int16_t flt_rnd   = (1<<(flt_scl-1));

   int      rsz_mod = -1;
   int      rsz_phs = -1;
   int      rsz_siz =  0;
   const int16_t* rsz_val =  0;

   if       (sw >= 2*dw)
   {
      rsz_mod = 2;
      rsz_phs = 4; // 1
      rsz_siz = 8;
      rsz_val = RSZ_GET_POLY(rsz_mod);
   }
   else if  (sw  >   dw)
   {
      rsz_mod = 1;
      rsz_phs = 8; // 3
      rsz_siz = 4;
      rsz_val = RSZ_GET_POLY(rsz_mod);
   }
   else if  (sw  <   dw)
   {
      rsz_mod = 0;
      rsz_phs = 8; // 3
      rsz_siz = 4;
      rsz_val = RSZ_GET_POLY(rsz_mod);
   }
   const int16_t rsz_scl   =  8;
   const int16_t rsz_rnd   = (1<<(rsz_scl-1));

   const int rsz_one    = (1 << HRSZ_Q_F);
   const int rsz_sinc   = (sw * rsz_one) / dw;    // as per vertical
   const int rsz_sbeg   = (rsz_sinc >> 1);
   const int rsz_send   = rsz_sbeg + ((dw-1)*rsz_sinc);

   // output format
   const int16_t ofmt_scl = 7;
   const int16_t ofmt_off = (1 << (ofmt_scl -1));

   {
      for (int y=0; y<dh; ++y)
      {
         GetROW(src, &IBUF[wpad], 0, y, wpad, sw, ss);

         if (rsz_mod >= 0)
         {
            HRSZ_RSZ_POLY(&OBUF[wpad], &IBUF[wpad], dw,
                  rsz_sbeg, rsz_sinc,
                  rsz_val, rsz_phs, rsz_siz,
                  rsz_scl, rsz_rnd);

         }

         PutROW(dst, &OBUF[wpad], 0, y, dw, ds);
      }
   }

   return rval;
}

int GetCOL(uint16_t* s, uint16_t* dst, int b, int x, int pad, int sh, int ss)
{
   int rval = 0;

   const uint16_t* src = s + b + x * 1;

   const int h = sh;
   int y;
   for (y=0; y<h; ++y)
   {
      dst[y] =  src[0];
      src   += ss;
   }

   // PADDING
   if (pad>0)
   {
      for (y=-pad; y<0; ++y)
         dst[y] = dst[0];
      for (y=0; y<pad; ++y)
         dst[h+y] = dst[h-1];
   }

   return rval;
}

int PutCOL(uint16_t* d, uint16_t* src, int b, int x, int dh, int ds)
{
   int rval = 0;

   uint16_t* dst = d + b + x * 1;

   const int h = dh;
   int y;
   for (y=0; y<h; ++y)
   {
      dst[0] =  src[y];
      dst   += ds;
   }

   return rval;
}

int GetROW(uint16_t* s, uint16_t* dst, int b, int y, int pad, int sw, int ss)
{
   int rval = 0;

   const uint16_t* src = s + b + y*ss;

   const int w = sw;
   int x;
   for (x=0; x<w; ++x)
   {
      dst[x] =  src[0];
      src   += 1;       // 1 for 8-bit image
   }

   // PADDING
   if (pad>0)
   {
      for (x=-pad; x<0; ++x)
         dst[x] = dst[0];
      for (x=0; x<pad; ++x)
         dst[w+x] = dst[w-1];
   }

   return rval;
}

int PutROW(uint16_t* d, const uint16_t* src, int b, int y, int dw, int ds)
{
   int rval = 0;

   uint16_t* dst = d + b + y*ds;

   const int w = dw;
   int x;
   for (x=0; x<w; ++x)
   {
      dst[0] =  src[x];
      dst   += 1;          // for 8-bit image
   }

   return rval;
}

// Same as VRSZ_RSZ_POLY except for the dscl value.  TODO fix this - use 1 function with 1 extra parameter
int
VRSZ_RSZ_POLY(
    uint16_t* pdst,
    const uint16_t* psrc,
    int dsiz,              //!< Destination Size   (OROI)
    int sbeg,              //!< Source Begin       (IROI)
    int sinc,              //!< Source Increment
    const int16_t* fbnk,   //!< Filter Bank Coefficients
    int rphs,              //!< Filter Bank Number of Phases
    int rsiz,              //!< Filter Bank Size (per phase)
    int rscl,              //!< Filter Results Scaling
    int rrnd)              //!< Filter Results Rounding Bias
{
   int rval = 0;

   // saturation value
   const int32_t dmin = 0;
   const int32_t dmax = UINT8_MAX;

   const int32_t dscl = VRSZ_Q_F;

   // conversion of fphs
   switch (rphs)
   {
   case  8:  rphs = 3; break; // filter size:  4
   case  4:  rphs = 2; break; // filter size:  8
   case  2:  rphs = 1; break; // filter size: 16
   case  1:                   // filter size: 32
   // n/a
   default:
            rphs = 0;
      break;
   }

   // source/destination positions
   int32_t S, D;

   // correction of starting point
   S = sbeg - (((rsiz-1) >> 1) << dscl);

   for (D=0; D<dsiz; ++D, S += sinc)
   {
      // extraction of interpolation parameters
      const int32_t FB = (S  >> dscl);             // filter source (integer)
      const int32_t FF = (S  & ((1 << dscl)-1));   // filter source (fraction)
      const int32_t FP = (FF >> (dscl - rphs));    // filter phase

      // input selection
      const uint16_t* s = psrc + FB;
      // filter selection
      const int16_t* flt = fbnk + (FP * rsiz);

      // filter
      int32_t d = 0;
      for (int fk=0; fk<rsiz; ++fk)
         d += ((int32_t)flt[fk] * (int32_t)s[fk]);
         
      // rounding and scaling
      d  += rrnd;
      d >>= rscl;


      // saturation
      if       (d < dmin) d = dmin;
      else if  (d > dmax) d = dmax;

      pdst[D] = d;
   }
   
   return rval;
}



/*!
   Generic Resizing using Polyphase Filter.
      - Filter Coefficients  S10 [ -512, 511 ]
      - Internal Accumulator S32 (28-bit signed).
      - Rounding toward minus infinity (with bias)
      - Saturation           S16 [ -INT16_MAX, +INT16_MAX ].
 */
int
HRSZ_RSZ_POLY(
    uint16_t* pdst,
    const uint16_t* psrc,
    int dsiz,              //!< Destination Size   (OROI)
    int sbeg,              //!< Source Begin       (IROI)
    int sinc,              //!< Source Increment
    const int16_t* fbnk,   //!< Filter Bank Coefficients
    int rphs,              //!< Filter Bank Number of Phases
    int rsiz,              //!< Filter Bank Size (per phase)
    int rscl,              //!< Filter Results Scaling
    int rrnd)              //!< Filter Results Rounding Bias
{
   int rval = 0;

   // saturation value
   const int32_t dmin = 0;
   const int32_t dmax = UINT8_MAX;

   const int     dscl = HRSZ_Q_F;

   // conversion of fphs
   switch (rphs)
   {
   case  8:  rphs = 3; break; // filter size:  4
   case  4:  rphs = 2; break; // filter size:  8
   case  2:  rphs = 1; break; // filter size: 16
   case  1:                   // filter size: 32
   // n/a
   default:
            rphs = 0;
      break;
   }

   // source/destination positions
   int S, D;

   // correction of starting point
   S = sbeg - (((rsiz-1) >> 1) << dscl);

   for (D=0; D<dsiz; ++D, S += sinc)
   {
      // extraction of interpolation parameters
      const int32_t FB = (S  >> dscl);             // filter source (integer)
      const int32_t FF = (S  & ((1 << dscl)-1));   // filter source (fraction)
      const int32_t FP = (FF >> (dscl - rphs));    // filter phase

      // input selection
      const uint16_t* s = psrc + FB;
      // filter selection
      const int16_t* flt = fbnk + (FP * rsiz);

      // filter
      int32_t d = 0;
      for (int fk=0; fk<rsiz; ++fk)
         d += ((int32_t)flt[fk] * (int32_t)s[fk]);

      // rounding and scaling
      d  += rrnd;
      d >>= rscl;

      // saturation
      if       (d < dmin) d = dmin;
      else if  (d > dmax) d = dmax;

      pdst[D] = d;
   }
   
   return rval;
}



/*!
 Polyphase Filter Coefficients for Resizing (Filter Bank).
 \todo:
    the filter bank should provide:
       - number of phases;
       - number of taps (size) of filter;
       - polyphase filter coefficient values;
       - filter scale and rounding;
 */
const short*
RSZ_GET_POLY(int i)
{
   static const short sSCL_RSZ_FLT[][32] =
   {
      // FILTERS
      // const short FUP[] =
      {   0, 256,  0,   0,
        -11, 245,  23,  -1,
        -17, 220,  58,  -5,
        -18, 184, 100, -10,\
        -15, 143, 143, -15,
        -10, 100, 184, -18,
         -5,  58, 220, -17,
         -1,  23, 245, -11,
      },

      // const short FD1[] =
      { 28, 200,  28, 0,
        15, 194,  47, 0,
         7, 178,  71, 0,
         2, 156,  98, 0,
         0, 128, 128, 0,
         0,  98, 156, 2,
         0,  71, 178, 7,
         0,  47, 194, 15,
      },

      // const short FD2[] =
      {  2, 32, 94,  94, 32,  2, 0, 0,
         0, 19, 80, 105, 47,  5, 0, 0,
         0, 11, 64, 106, 64, 11, 0, 0,
         0,  5, 47, 105, 80, 19, 0, 0,
      },
   };

   return sSCL_RSZ_FLT[i];
}



void kernelresample_float(float *input, float *out, int inw, int inh, int dstw, int dsth, int d, float r)
{
  uint16_t *fix_input = (uint16_t *)alMalloc(inw*inh*sizeof(uint16_t), 16);
  uint16_t *fix_out   = (uint16_t *)alMalloc(dstw*dsth*sizeof(uint16_t),16);
  uint16_t *fix_temp  = (uint16_t *)alMalloc(dstw*inh*sizeof(uint16_t),16);
  
  for(int index = 0; index < d; index++)
  {
    for (int x = 0; x < inw; ++x)
    {
        for (int y = 0; y < inh; ++y)
        {
            // convert to 8 bit fixed point precision 
            fix_input[y*inw + x] = ((uint16_t)(input[x*inh + y + index*inw*inh]*pow(2.0f,15)))>> 8;
        }
    }
    if (inw == dstw)
        vertical_Scale_08U(fix_input, inw, inh, inw, fix_out, dstw, dsth, dstw);    //Resize vertical
    else if (inh == dsth)
        horizontal_Scale_08U(fix_input, inw, inh, inw, fix_out, dstw, dsth, dstw);    //Resize Horizontal
    else
    {
        // Horizontal then vertical resize
        horizontal_Scale_08U(fix_input, inw, inh, inw, fix_temp, dstw, inh, dstw);
        vertical_Scale_08U(fix_temp, dstw, inh, dstw, fix_out, dstw, dsth, dstw);
    }
    
    for (int x = 0; x < dstw; ++x)
    {
        for (int y = 0; y < dsth; ++y)
        {
            out[x*dsth + y + index*dsth*dstw] = (float)(fix_out[y*dstw + x]<<8)/pow(2.0f,15)*r;
        }
    }
  }
  
  alFree(fix_input);
  alFree(fix_out);
  alFree(fix_temp);
}


void kernelresample_double(double *input, double *out, int inw, int inh, int dstw, int dsth, int d, float r)
{
  uint16_t *fix_input = (uint16_t *)alMalloc(inw*inh*sizeof(uint16_t), 16);
  uint16_t *fix_out   = (uint16_t *)alMalloc(dstw*dsth*sizeof(uint16_t),16);
  uint16_t *fix_temp  = (uint16_t *)alMalloc(dstw*inh*sizeof(uint16_t),16);
  
  for(int index = 0; index < d; index++)
  {
    for (int x = 0; x < inw; ++x)
    {
        for (int y = 0; y < inh; ++y)
        {
            // convert to 8 bit fixed point precision 
            fix_input[y*inw + x] = ((uint16_t)(input[x*inh + y + index*inw*inh]*pow(2.0f,15)))>> 8;
        }
    }
    if (inw == dstw)
        vertical_Scale_08U(fix_input, inw, inh, inw, fix_out, dstw, dsth, dstw);    //Resize vertical
    else if (inh == dsth)
        horizontal_Scale_08U(fix_input, inw, inh, inw, fix_out, dstw, dsth, dstw);    //Resize Horizontal
    else
    {
        // Horizontal then vertical resize
        horizontal_Scale_08U(fix_input, inw, inh, inw, fix_temp, dstw, inh, dstw);
        vertical_Scale_08U(fix_temp, dstw, inh, dstw, fix_out, dstw, dsth, dstw);
    }
    
    for (int x = 0; x < dstw; ++x)
    {
        for (int y = 0; y < dsth; ++y)
        {
            out[x*dsth + y + index*dsth*dstw] = (double)(fix_out[y*dstw + x]<<8)/pow(2.0f,15)*r;
        }
    }
  }
  
  alFree(fix_input);
  alFree(fix_out);
  alFree(fix_temp);
}

void kernelresample_fix(uint8_t *input, uint8_t *out, int inw, int inh, int dstw, int dsth, int d)
{
  uint16_t *fix_input = (uint16_t *)alMalloc(inw*inh*sizeof(uint16_t), 16);
  uint16_t *fix_out   = (uint16_t *)alMalloc(dstw*dsth*sizeof(uint16_t),16);
  uint16_t *fix_temp  = (uint16_t *)alMalloc(dstw*inh*sizeof(uint16_t),16);
  
  //mexPrintf("input w/h %d/%d, output w/h %d/%d d= %d \n", inw, inh, dstw, dsth, d); 
  
  for(int index = 0; index < d; index++)
  {
    for (int x = 0; x < inw; ++x)
    {
        for (int y = 0; y < inh; ++y)
        {
            // convert to 8 bit fixed point precision 
            fix_input[y*inw + x] = (uint16_t)input[x*inh + y + index*inw*inh];
        }
    }
    if (inw == dstw)
        vertical_Scale_08U(fix_input, inw, inh, inw, fix_out, dstw, dsth, dstw);    //Resize vertical
    else if (inh == dsth)
        horizontal_Scale_08U(fix_input, inw, inh, inw, fix_out, dstw, dsth, dstw);    //Resize Horizontal
    else
    {
        // Horizontal then vertical resize
        horizontal_Scale_08U(fix_input, inw, inh, inw, fix_temp, dstw, inh, dstw);
        vertical_Scale_08U(fix_temp, dstw, inh, dstw, fix_out, dstw, dsth, dstw);
    }
    
    for (int x = 0; x < dstw; ++x)
    {
        for (int y = 0; y < dsth; ++y)
        {
            out[x*dsth + y + index*dsth*dstw] = (uint8_t)fix_out[y*dstw + x];
        }
    }
  }
  
  alFree(fix_input);
  alFree(fix_out);
  alFree(fix_temp);
    
    
}



// compute interpolation values for single column for resapling
template<class T> void resampleCoef( int ha, int hb, int &n, int *&yas,
  int *&ybs, T *&wts, int bd[2], int pad=0 )
{
  const T s = T(hb)/T(ha), sInv = 1/s; T wt, wt0=T(1e-3)*s;
  bool ds=ha>hb; int nMax; bd[0]=bd[1]=0;
  if(ds) { n=0; nMax=ha+(pad>2 ? pad : 2)*hb; } else { n=nMax=hb; }
  // initialize memory
  wts = (T*)alMalloc(nMax*sizeof(T),16);
  yas = (int*)alMalloc(nMax*sizeof(int),16);
  ybs = (int*)alMalloc(nMax*sizeof(int),16);
  if( ds ) for( int yb=0; yb<hb; yb++ ) {
    // create coefficients for downsampling
    T ya0f=yb*sInv, ya1f=ya0f+sInv, W=0;
    int ya0=int(ceil(ya0f)), ya1=int(ya1f), n1=0;
    for( int ya=ya0-1; ya<ya1+1; ya++ ) {
      wt=s; if(ya==ya0-1) wt=(ya0-ya0f)*s; else if(ya==ya1) wt=(ya1f-ya1)*s;
      if(wt>wt0 && ya>=0) { ybs[n]=yb; yas[n]=ya; wts[n]=wt; n++; n1++; W+=wt; }
    }
    if(W>1) for( int i=0; i<n1; i++ ) wts[n-n1+i]/=W;
    if(n1>bd[0]) bd[0]=n1;
    while( n1<pad ) { ybs[n]=yb; yas[n]=yas[n-1]; wts[n]=0; n++; n1++; }
  } else for( int yb=0; yb<hb; yb++ ) {
    // create coefficients for upsampling
    T yaf = (T(.5)+yb)*sInv-T(.5); int ya=(int) floor(yaf);
    wt=1; if(ya>=0 && ya<ha-1) wt=1-(yaf-ya);
    if(ya<0) { ya=0; bd[0]++; } if(ya>=ha-1) { ya=ha-1; bd[1]++; }
    ybs[yb]=yb; yas[yb]=ya; wts[yb]=wt;
  }
}

// resample A using bilinear interpolation and and store result in B
template<class T>
void resample( T *A, T *B, int ha, int hb, int wa, int wb, int d, T r ) {
  int hn, wn, x, x1, y, z, xa, xb, ya; T *A0, *A1, *A2, *A3, *B0, wt, wt1;
  T *C = (T*) alMalloc((ha+4)*sizeof(T),16); for(y=ha; y<ha+4; y++) C[y]=0;
  bool sse = (typeid(T)==typeid(float)) && !(size_t(A)&15) && !(size_t(B)&15);
  // get coefficients for resampling along w and h
  int *xas, *xbs, *yas, *ybs; T *xwts, *ywts; int xbd[2], ybd[2];
  resampleCoef<T>( wa, wb, wn, xas, xbs, xwts, xbd, 0 );
  resampleCoef<T>( ha, hb, hn, yas, ybs, ywts, ybd, 4 );
  if( wa==2*wb ) r/=2; if( wa==3*wb ) r/=3; if( wa==4*wb ) r/=4;
  r/=T(1+1e-6); for( y=0; y<hn; y++ ) ywts[y] *= r;
  // resample each channel in turn
  for( z=0; z<d; z++ ) for( x=0; x<wb; x++ ) {
    if(x==0) x1=0; xa=xas[x1]; xb=xbs[x1]; wt=xwts[x1]; wt1=1-wt; y=0;
    A0=A+z*ha*wa+xa*ha; A1=A0+ha, A2=A1+ha, A3=A2+ha; B0=B+z*hb*wb+xb*hb;
    // variables for SSE (simple casts to float)
    float *Af0, *Af1, *Af2, *Af3, *Bf0, *Cf, *ywtsf, wtf, wt1f;
    Af0=(float*) A0; Af1=(float*) A1; Af2=(float*) A2; Af3=(float*) A3;
    Bf0=(float*) B0; Cf=(float*) C;
    ywtsf=(float*) ywts; wtf=(float) wt; wt1f=(float) wt1;
    // resample along x direction (A -> C)
    #define FORs(X) if(sse) for(; y<ha-4; y+=4) STR(Cf[y],X);
    #define FORr(X) for(; y<ha; y++) C[y] = X;
    if( wa==2*wb ) {
      FORs( ADD(LDu(Af0[y]),LDu(Af1[y])) );
      FORr( A0[y]+A1[y] ); x1+=2;
    } else if( wa==3*wb ) {
      FORs( ADD(LDu(Af0[y]),LDu(Af1[y]),LDu(Af2[y])) );
      FORr( A0[y]+A1[y]+A2[y] ); x1+=3;
    } else if( wa==4*wb ) {
      FORs( ADD(LDu(Af0[y]),LDu(Af1[y]),LDu(Af2[y]),LDu(Af3[y])) );
      FORr( A0[y]+A1[y]+A2[y]+A3[y] ); x1+=4;
    } else if( wa>wb ) {
      int m=1; while( x1+m<wn && xb==xbs[x1+m] ) m++; float wtsf[4];
      for( int x0=0; x0<(m<4?m:4); x0++ ) wtsf[x0]=float(xwts[x1+x0]);
      #define U(x) MUL( LDu(*(Af ## x + y)), SET(wtsf[x]) )
      #define V(x) *(A ## x + y) * xwts[x1+x]
      if(m==1) { FORs(U(0));                     FORr(V(0)); }
      if(m==2) { FORs(ADD(U(0),U(1)));           FORr(V(0)+V(1)); }
      if(m==3) { FORs(ADD(U(0),U(1),U(2)));      FORr(V(0)+V(1)+V(2)); }
      if(m>=4) { FORs(ADD(U(0),U(1),U(2),U(3))); FORr(V(0)+V(1)+V(2)+V(3)); }
      #undef U
      #undef V
      for( int x0=4; x0<m; x0++ ) {
        A1=A0+x0*ha; wt1=xwts[x1+x0]; Af1=(float*) A1; wt1f=float(wt1); y=0;
        FORs(ADD(LD(Cf[y]),MUL(LDu(Af1[y]),SET(wt1f)))); FORr(C[y]+A1[y]*wt1);
      }
      x1+=m;
    } else {
      bool xBd = x<xbd[0] || x>=wb-xbd[1]; x1++;
      if(xBd) memcpy(C,A0,ha*sizeof(T));
      if(!xBd) FORs(ADD(MUL(LDu(Af0[y]),SET(wtf)),MUL(LDu(Af1[y]),SET(wt1f))));
      if(!xBd) FORr( A0[y]*wt + A1[y]*wt1 );
    }
    #undef FORs
    #undef FORr
    // resample along y direction (B -> C)
    if( ha==hb*2 ) {
      T r2 = r/2; int k=((~((size_t) B0) + 1) & 15)/4; y=0;
      for( ; y<k; y++ )  B0[y]=(C[2*y]+C[2*y+1])*r2;
      if(sse) for(; y<hb-4; y+=4) STR(Bf0[y],MUL((float)r2,_mm_shuffle_ps(ADD(
        LDu(Cf[2*y]),LDu(Cf[2*y+1])),ADD(LDu(Cf[2*y+4]),LDu(Cf[2*y+5])),136)));
      for( ; y<hb; y++ ) B0[y]=(C[2*y]+C[2*y+1])*r2;
    } else if( ha==hb*3 ) {
      for(y=0; y<hb; y++) B0[y]=(C[3*y]+C[3*y+1]+C[3*y+2])*(r/3);
    } else if( ha==hb*4 ) {
      for(y=0; y<hb; y++) B0[y]=(C[4*y]+C[4*y+1]+C[4*y+2]+C[4*y+3])*(r/4);
    } else if( ha>hb ) {
      y=0;
      //if( sse && ybd[0]<=4 ) for(; y<hb; y++) // Requires SSE4
      //  STR1(Bf0[y],_mm_dp_ps(LDu(Cf[yas[y*4]]),LDu(ywtsf[y*4]),0xF1));
      #define U(o) C[ya+o]*ywts[y*4+o]
      if(ybd[0]==2) for(; y<hb; y++) { ya=yas[y*4]; B0[y]=U(0)+U(1); }
      if(ybd[0]==3) for(; y<hb; y++) { ya=yas[y*4]; B0[y]=U(0)+U(1)+U(2); }
      if(ybd[0]==4) for(; y<hb; y++) { ya=yas[y*4]; B0[y]=U(0)+U(1)+U(2)+U(3); }
      if(ybd[0]>4)  for(; y<hn; y++) { B0[ybs[y]] += C[yas[y]] * ywts[y]; }
      #undef U
    } else {
      for(y=0; y<ybd[0]; y++) B0[y] = C[yas[y]]*ywts[y];
      for(; y<hb-ybd[1]; y++) B0[y] = C[yas[y]]*ywts[y]+C[yas[y]+1]*(r-ywts[y]);
      for(; y<hb; y++)        B0[y] = C[yas[y]]*ywts[y];
    }
  }
  alFree(xas); alFree(xbs); alFree(xwts); alFree(C);
  alFree(yas); alFree(ybs); alFree(ywts);
}



// B = imResampleMex(A,hb,wb,nrm); see imResample.m for usage details
#ifdef MATLAB_MEX_FILE
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
  int *ns, ms[3], n, m, nCh, nDims;
  void *A, *B; mxClassID id; double nrm;

  // Error checking on arguments
  if( nrhs!=4) mexErrMsgTxt("Four inputs expected.");
  if( nlhs>1 ) mexErrMsgTxt("One output expected.");
  nDims=mxGetNumberOfDimensions(prhs[0]); id=mxGetClassID(prhs[0]);
  ns = (int*) mxGetDimensions(prhs[0]); nCh=(nDims==2) ? 1 : ns[2];
  if( (nDims!=2 && nDims!=3) ||
    (id!=mxSINGLE_CLASS && id!=mxDOUBLE_CLASS && id!=mxUINT8_CLASS) )
    mexErrMsgTxt("A should be 2D or 3D single, double or uint8 array.");
  ms[0]=(int)mxGetScalar(prhs[1]); ms[1]=(int)mxGetScalar(prhs[2]); ms[2]=nCh;
  if( ms[0]<=0 || ms[1]<=0 ) mexErrMsgTxt("downsampling factor too small.");
  nrm=(double)mxGetScalar(prhs[3]);

  // create output array
  plhs[0] = mxCreateNumericArray(3, (const mwSize*) ms, id, mxREAL);
  n=ns[0]*ns[1]*nCh; m=ms[0]*ms[1]*nCh;

  //mexPrintf("input w/h %d/%d, output w/h %d/%d \n", ns[0], ns[1], ms[0], ms[1]); 
  //mexPrintf("input num_chs %d nrm %f \n", nCh, float(n)); 
  
  // perform resampling (w appropriate type)
  A=mxGetData(prhs[0]); B=mxGetData(plhs[0]);
  if( id==mxDOUBLE_CLASS ) {
    //mexPrintf("mxDOUBLE_CLASS\n");
    kernelresample_double((double*)A, (double*)B, ns[1], ns[0], ms[1], ms[0], nCh, float(nrm));
  } else if( id==mxSINGLE_CLASS ) {
    //mexPrintf("mxSINGLE_CLASS\n");
    kernelresample_float((float*)A, (float*)B, ns[1], ns[0], ms[1], ms[0], nCh, float(nrm));
  } else if( id==mxUINT8_CLASS ) {
      //mexPrintf("mxUINT8_CLASS\n");
      //kernelresample_fix((uint8_t *)A, (uint8_t *)B, ns[1], ns[0], ms[1], ms[0], nCh);
  
     float *A1 = (float*) mxMalloc(n*sizeof(float));
     float *B1 = (float*) mxCalloc(m,sizeof(float));
     for(int i=0; i<n; i++) A1[i]=(float) ((uchar*)A)[i];
     resample(A1, B1, ns[0], ms[0], ns[1], ms[1], nCh, float(nrm));
     for(int i=0; i<m; i++) ((uchar*)B)[i]=(uchar) (B1[i]+.5);
  } else {
    mexErrMsgTxt("Unsupported type.");
  }
}
#endif
